import java.util.*;
class Que3
{
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the value of a");
		int a= sc.nextInt();
		System.out.println("Enter the value of b");
		int b= sc.nextInt();
		System.out.println("Before Swap:"+"a = "+a+" b = "+b);
		int temp;
		temp=a;
		a=b;
		b=temp;
		System.out.println("After Swap:"+"a = "+a+" b = "+b);
	}
}