import java.util.*;
class Que5
{
	public static void main(String args[])
	{
	 	Scanner sc=new Scanner(System.in);
		int a[]=new int[4];
		for(int i=0;i<a.length;i++)
		{
			System.out.println("Enter the Elements:");
			a[i]=sc.nextInt();
		}
		System.out.println("The given Array is: ");
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		System.out.println("The Reverse Array is: ");
		for(int i=a.length-1;i>=0;i--)
		{
			System.out.println(a[i]);
		}
	}
}