class Que1
{
	public static void main(String args[])
	{
		int a=10;
		int b=20;
		int c= a+b;
		System.out.println("Sum of "+ a +" + "+ b +" is: "+c);
	}
}