import java.util.*;
class Que7
{
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the first number");
		int a= sc.nextInt();
		System.out.println("Enter the second number");
		int b= sc.nextInt();
		System.out.println("Enter the third number");
		float c= sc.nextFloat();
		System.out.println("Enter the fourth number");
		float d= sc.nextFloat();
		long e = a+b;
		double f= c+d;
		System.out.println("sum of:"+a+" + "+b+" is: "+e);
		System.out.println("sum of:"+c+" + "+d+" is: "+f);
		
		
	}
}
