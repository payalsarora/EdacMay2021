import java.util.*;
class Que6
{
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the First Element :");
		int a= sc.nextInt();
		System.out.println("Enter the Second Element :");
		int b= sc.nextInt();
		System.out.println("Enter the Third Element :");
		int c= sc.nextInt();
		if(a>b && a>c)
			System.out.println(a +" is a maximum");
		else if(b>a && b>c)
			System.out.println(b +" is a maximum");
		else
			System.out.println(c +" is a maximum");
	}
}